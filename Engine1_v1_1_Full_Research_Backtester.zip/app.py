import streamlit as st
from data.loader import get_data
from engine.strategy import run_strategy
from visualization.dashboard import render

st.set_page_config(layout="wide")
st.title("ENGINE 1 v1.1 - FULL RESEARCH BACKTESTER")

data=get_data()
result=run_strategy(data)
render(data,result)
