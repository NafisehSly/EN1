import streamlit as st
import plotly.graph_objects as go

def chart(df,title):
    fig=go.Figure()
    fig.add_trace(go.Candlestick(x=df.time,open=df.open,high=df.high,low=df.low,close=df.close))
    fig.update_layout(title=title,height=500)
    return fig

def render(data,result):
    st.metric("SIGNAL",result["signal"])
    for tf in ["4H","1H","15M"]:
        st.plotly_chart(chart(data[tf],"BTC "+tf),use_container_width=True)
    st.write(result)
