import pandas as pd
import ta

def run_backtest(df, capital, risk, fee, slippage):

    x=df.copy()

    x["ema20"]=ta.trend.EMAIndicator(
        x.close,20
    ).ema_indicator()

    x["ema200"]=ta.trend.EMAIndicator(
        x.close,200
    ).ema_indicator()

    x["rsi"]=ta.momentum.RSIIndicator(
        x.close
    ).rsi()

    x["adx"]=ta.trend.ADXIndicator(
        x.high,x.low,x.close
    ).adx()

    x["atr"]=ta.volatility.AverageTrueRange(
        x.high,x.low,x.close
    ).average_true_range()

    balance=capital
    trades=[]
    equity=[]

    position=None

    for i in range(200,len(x)):

        r=x.iloc[i]

        if position is None:

            if (
                r.close > r.ema20
                and r.rsi > 50
                and r.adx > 30
            ):

                risk_money=balance*risk/100
                stop=r.close-r.atr*1.5

                size=risk_money/(r.close-stop)

                position={
                    "entry":r.close,
                    "stop":stop,
                    "target":r.close+r.atr*3,
                    "size":size
                }


        else:

            exit_price=None

            if r.low <= position["stop"]:
                exit_price=position["stop"]

            elif r.high >= position["target"]:
                exit_price=position["target"]

            if exit_price:

                pnl=(exit_price-position["entry"])*position["size"]

                pnl -= abs(pnl)*(fee+slippage)/100

                balance += pnl

                trades.append({
                    "entry":position["entry"],
                    "exit":exit_price,
                    "pnl":round(pnl,2),
                    "balance":round(balance,2)
                })

                position=None

        equity.append({
            "time":r.time,
            "balance":balance
        })

    t=pd.DataFrame(trades)

    return {
        "initial":capital,
        "final":round(balance,2),
        "return":round((balance-capital)/capital*100,2),
        "trades":t,
        "equity":pd.DataFrame(equity)
    }