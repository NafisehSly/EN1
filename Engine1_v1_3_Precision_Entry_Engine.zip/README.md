# Engine1 v1.3 Precision Entry Engine

Upgrades:
- Volume confirmation
- Strong ADX filter
- RSI reclaim entry
- EMA pullback confirmation
- Separate LONG/SHORT statistics
- Entry/exit markers framework
- Equity curve

Run:
pip install -r requirements.txt
python3 -m streamlit run app.py