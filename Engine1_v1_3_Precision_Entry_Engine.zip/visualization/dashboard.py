import streamlit as st
import plotly.graph_objects as go

def render(data,result):

    c1,c2,c3,c4=st.columns(4)

    c1.metric("Trades",len(result["trades"]))
    c2.metric("Win Rate",str(result["win_rate"])+"%")
    c3.metric("Profit",result["profit"])
    c4.metric("LONG / SHORT",f'{result["longs"]}/{result["shorts"]}')

    st.subheader("Equity Curve")

    if not result["equity"].empty:
        fig=go.Figure()
        fig.add_trace(go.Scatter(
            x=result["equity"].time,
            y=result["equity"].equity
        ))
        st.plotly_chart(fig,use_container_width=True)

    st.subheader("Trade Log")
    st.dataframe(result["trades"])