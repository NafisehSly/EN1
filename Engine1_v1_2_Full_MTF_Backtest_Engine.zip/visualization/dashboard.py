import streamlit as st
import plotly.graph_objects as go

def render(data,result):

    st.metric("Trades", len(result["trades"]))
    st.metric("Win Rate", str(result["win_rate"])+"%")
    st.metric("Profit", result["profit"])

    st.subheader("Equity Curve")

    if not result["equity"].empty:
        fig=go.Figure()
        fig.add_trace(go.Scatter(
            x=result["equity"].time,
            y=result["equity"].equity
        ))
        st.plotly_chart(fig,use_container_width=True)

    st.subheader("Trade Log")
    st.dataframe(result["trades"])