# Engine1 v1.2 Full MTF Backtest Engine

Features:
- 4H / 1H / 15M strategy simulation
- LONG / SHORT detection
- ATR stop loss and take profit
- Trend lost exit
- Entry/exit markers
- Equity curve
- Drawdown
- Trade log
- Performance metrics

Run:
pip install -r requirements.txt
python3 -m streamlit run app.py