import streamlit as st
from data.loader import get_data
from engine.backtester import run_backtest
from visualization.dashboard import render

st.set_page_config(layout="wide")

st.title("ENGINE 1 v1.2 - FULL MTF BACKTEST ENGINE")

data = get_data()

result = run_backtest(data)

render(data, result)