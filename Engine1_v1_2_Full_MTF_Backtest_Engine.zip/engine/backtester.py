import pandas as pd
import ta

def prepare(df):
    x=df.copy()
    x["ema20"]=ta.trend.EMAIndicator(x.close,20).ema_indicator()
    x["ema200"]=ta.trend.EMAIndicator(x.close,200).ema_indicator()
    x["rsi"]=ta.momentum.RSIIndicator(x.close).rsi()
    x["adx"]=ta.trend.ADXIndicator(x.high,x.low,x.close).adx()
    x["atr"]=ta.volatility.AverageTrueRange(
        x.high,x.low,x.close
    ).average_true_range()
    return x

def run_backtest(data):

    h4=prepare(data["4H"])
    h1=prepare(data["1H"])
    m15=prepare(data["15M"])

    trades=[]
    position=None
    equity=0
    curve=[]

    for i in range(220,len(m15)):

        row=m15.iloc[i]

        signal=None

        if position is None:

            if (
                h4.close.iloc[-1] > h4.ema200.iloc[-1]
                and h1.adx.iloc[-1] > 25
                and row.close > row.ema20
                and row.rsi > 45
            ):
                signal="LONG"

            elif (
                h4.close.iloc[-1] < h4.ema200.iloc[-1]
                and h1.adx.iloc[-1] > 25
                and row.close < row.ema20
                and row.rsi < 55
            ):
                signal="SHORT"

            if signal:
                position={
                    "side":signal,
                    "entry":row.close,
                    "stop": row.close-row.atr*1.5 if signal=="LONG" else row.close+row.atr*1.5,
                    "target": row.close+row.atr*3 if signal=="LONG" else row.close-row.atr*3
                }

        else:
            exit_price=None
            reason=None

            if position["side"]=="LONG":
                if row.low <= position["stop"]:
                    exit_price=position["stop"]
                    reason="STOP"
                elif row.high >= position["target"]:
                    exit_price=position["target"]
                    reason="TARGET"

            else:
                if row.high >= position["stop"]:
                    exit_price=position["stop"]
                    reason="STOP"
                elif row.low <= position["target"]:
                    exit_price=position["target"]
                    reason="TARGET"

            if exit_price:
                pnl = exit_price-position["entry"] if position["side"]=="LONG" else position["entry"]-exit_price
                equity += pnl
                trades.append({
                    "side":position["side"],
                    "entry":position["entry"],
                    "exit":exit_price,
                    "pnl":pnl,
                    "reason":reason
                })
                position=None

        curve.append({"time":row.time,"equity":equity})

    df=pd.DataFrame(trades)

    return {
        "trades":df,
        "equity":pd.DataFrame(curve),
        "profit":round(df.pnl.sum(),2) if not df.empty else 0,
        "win_rate":round((df.pnl>0).mean()*100,2) if not df.empty else 0
    }