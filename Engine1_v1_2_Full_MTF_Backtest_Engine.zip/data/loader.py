import requests
import pandas as pd

def fetch(interval, limit=1000):
    raw = requests.get(
        "https://api.binance.com/api/v3/klines",
        params={"symbol":"BTCUSDT","interval":interval,"limit":limit}
    ).json()

    df = pd.DataFrame(raw, columns=[
        "time","open","high","low","close","volume",
        "a","b","c","d","e","f"
    ])

    for c in ["open","high","low","close","volume"]:
        df[c] = df[c].astype(float)

    df["time"] = pd.to_datetime(df["time"], unit="ms")
    return df

def get_data():
    return {
        "4H": fetch("4h"),
        "1H": fetch("1h"),
        "15M": fetch("15m")
    }