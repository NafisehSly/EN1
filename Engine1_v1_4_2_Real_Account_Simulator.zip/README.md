Engine1 v1.4.2 Real Account Simulator

Features:
- v1.3 precision entry logic
- initial capital
- risk based position sizing
- fee calculation
- real balance simulation
- equity curve
- trade log

Run:
pip install -r requirements.txt
python3 -m streamlit run app.py